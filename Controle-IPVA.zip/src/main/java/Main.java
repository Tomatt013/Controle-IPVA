import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
      System.out.print("Digite o número final da placa do veículo: ");
            int finalPlaca = scanner.nextInt();

            switch (finalPlaca) {
                case 1:
                    System.out.println("Pagamento até 30/04");
                    break;
                case 2:
                    System.out.println("Pagamento até 31/05");
                    break;
                case 3:
                    System.out.println("Pagamento até 30/06");
                    break;
                case 4:
                    System.out.println("Pagamento até 31/07");
                    break;
                case 5:
                    System.out.println("Pagamento até 31/08");
                    break;
                case 6:
                    System.out.println("Pagamento até 30/09");
                    break;
                case 7:
                    System.out.println("Pagamento até 31/10");
                    break;
                case 8:
                    System.out.println("Pagamento até 30/11");
                    break;
                case 9:
                case 0:
                    System.out.println("Pagamento até 31/12");
                    break;
                default:
                    System.out.println("Valor digitado está incorreto.");
            }

            scanner.close();
        }
    }